    </main>



    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="../dist/js/jquery-3.4.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="../dist/js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="../dist/js/bootstrap.min.js"></script>


    <script type="text/javascript" src="../dist/datatable/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../dist/datatable/js/dataTables.bootstrap4.min.js"></script>
    
    <script type="text/javascript">
      $(document).ready(function(){
        $(".dropdown, .btn-group").hover(function(){
          var dropdownMenu = $(this).children(".dropdown-menu");

          if(dropdownMenu.is(":visible")){
            dropdownMenu.parent().toggleClass("open");
          }
        });
      });     
    </script>

    <script>
      $(document).ready(function() {
        $('#dataTable').DataTable();
      });
    </script>

    <!-- If you want to disable some features, use the following code. -->
    <!-- <script>
    $(function () {
      $('#dataTable').DataTable({
        "pageLength": 3,
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": true
        });
      });
    </script>  -->

    
  </body>
</html>