<?php 
  include 'includes/head.php'; 
  include 'includes/navigation.php'
?>






<?php include 'includes/footer.php'; ?>